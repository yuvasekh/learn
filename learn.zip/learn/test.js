const express=require('express')
const app=express()
app.use(express.json())
let temp=[10,1,2,3,4,5]
app.get('/hello',(req,res)=>
{
    res.send("hello world")
})
app.post('/add',(req,res)=>
{
    console.log(req.body)
    let a=req.body.a
    let b=req.body.b
    // console.log(a+b)
    res.send(a+b)
})
// app.listen(8001)
app.listen(8001, () => {
    console.log(`Server running on http://localhost:${8001}`);
});